gunzip *.gz
rename 's/pdb//' *.ent
rename 's/ent/pdb/' *.ent